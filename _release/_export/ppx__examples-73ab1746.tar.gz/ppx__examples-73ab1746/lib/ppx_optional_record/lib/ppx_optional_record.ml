(** @canonical Ppx_optional_record.OptionalRecord *)
module OptionalRecord = Ppx_optional_record__OptionalRecord
